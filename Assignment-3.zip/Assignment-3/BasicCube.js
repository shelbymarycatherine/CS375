/////////////////////////////////////////////////////////////////////////////
//
//  BasicCube.js
//
//  A cube defined of 12 triangles
//

class BasicCube {
    constructor(gl, vertexShader, fragmentShader) {

        // let program = new ShaderProgram(gl, this, vertexShader, fragmentShader);

        this.draw = () => {
            // program.use();
        };
    }
};