/////////////////////////////////////////////////////////////////////////////
//
//  IndexedCube.js
//
//  A cube defined of 12 triangles using vertex indices.
//

class IndexedCube {
    constructor(gl, vertexShader, fragmentShader) {

        // let program = new ShaderProgram(gl, this, vertexShader, fragmentShader);

        this.draw = () => {
            // program.use();
        };
    }
};
