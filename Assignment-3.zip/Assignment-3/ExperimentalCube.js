/////////////////////////////////////////////////////////////////////////////
//
//  ExperimentalCube.js
//
//  A cube defined ???
//

class ExperimentalCube {
    constructor(gl, vertexShader, fragmentShader) {

        // let program = new ShaderProgram(gl, this, vertexShader, fragmentShader);

        this.draw = () => {
            // program.use();
        };
    }
};